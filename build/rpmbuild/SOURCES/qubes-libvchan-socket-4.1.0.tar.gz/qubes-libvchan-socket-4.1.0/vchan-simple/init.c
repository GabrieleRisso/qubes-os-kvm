/*
 * The Qubes OS Project, http://www.qubes-os.org
 *
 * Copyright (C) 2020  Paweł Marczewski  <pawel@invisiblethingslab.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

#include "libvchan.h"
#include "libvchan_private.h"

#define SOCKET_DIR "/var/run/vchan"
#define VSOCK_PORT_BASE 10000

static int get_current_domain(void) {
    const char *s = getenv("VCHAN_DOMAIN");
    return s ? atoi(s) : 0;
}

static enum vchan_transport get_transport(void) {
    const char *t = getenv("VCHAN_TRANSPORT");
    if (t && strcmp(t, "vsock") == 0)
        return VCHAN_TRANSPORT_VSOCK;
    return VCHAN_TRANSPORT_UNIX;
}

static unsigned int vchan_to_vsock_port(int client_domain, int port) {
    const char *base_str = getenv("VCHAN_VSOCK_BASE_PORT");
    unsigned int base = base_str ? (unsigned int)atoi(base_str) : VSOCK_PORT_BASE;
    return base + (unsigned int)client_domain * 1000 + (unsigned int)port;
}

static libvchan_t *init(
    int server_domain, int client_domain, int port,
    size_t read_min) {

    libvchan_t *ctrl = malloc(sizeof(*ctrl));
    if (!ctrl)
        return NULL;

    ctrl->socket_path = NULL;
    ctrl->server_fd = -1;
    ctrl->socket_fd = -1;
    ctrl->is_new = true;
    ctrl->blocking = true;
    ctrl->transport = get_transport();

    if (ctrl->transport == VCHAN_TRANSPORT_VSOCK) {
        ctrl->vsock_cid = (unsigned int)server_domain;
        ctrl->vsock_port = vchan_to_vsock_port(client_domain, port);
    } else {
        const char *socket_dir = getenv("VCHAN_SOCKET_DIR");
        if (!socket_dir)
            socket_dir = SOCKET_DIR;

        if (asprintf(&ctrl->socket_path, "%s/vchan.%d.%d.%d.sock",
                     socket_dir, server_domain, client_domain, port) < 0) {
            perror("asprintf");
            free(ctrl);
            return NULL;
        }
    }

    if (ring_init(&ctrl->read_ring, read_min) < 0) {
        free(ctrl);
        return NULL;
    }

    return ctrl;
}

libvchan_t *libvchan_server_init(int domain, int port,
                                 size_t read_min,
                                 __attribute__((unused)) size_t write_min) {
    libvchan_t *ctrl = init(
        get_current_domain(), domain, port, read_min);
    if (!ctrl) {
        return NULL;
    }

    if (ctrl->transport == VCHAN_TRANSPORT_VSOCK) {
        ctrl->server_fd = libvchan__listen_vsock(ctrl->vsock_cid,
                                                  ctrl->vsock_port);
    } else {
        ctrl->server_fd = libvchan__listen(ctrl->socket_path);
    }
    if (ctrl->server_fd < 0) {
        libvchan_close(ctrl);
        return NULL;
    }

    return ctrl;
}

libvchan_t *libvchan_client_init(int domain, int port) {
    libvchan_t *ctrl = init(
        domain, get_current_domain(), port, 1024);
    if (!ctrl) {
        return NULL;
    }

    if (ctrl->transport == VCHAN_TRANSPORT_VSOCK) {
        ctrl->socket_fd = libvchan__connect_vsock(ctrl->vsock_cid,
                                                   ctrl->vsock_port);
    } else {
        ctrl->socket_fd = libvchan__connect(ctrl->socket_path);
    }
    if (ctrl->socket_fd < 0) {
        libvchan_close(ctrl);
        return NULL;
    }

    return ctrl;
}

libvchan_t *libvchan_client_init_async(int domain, int port, int *watch_fd) {
    int pipe_fds[2];
    libvchan_t *ctrl;

    ctrl = libvchan_client_init(domain, port);

    if (!ctrl)
        return NULL;

    if (pipe(pipe_fds) < 0) {
        libvchan_close(ctrl);
        return NULL;
    }

    write(pipe_fds[1], "a", 1);
    close(pipe_fds[1]);
    ctrl->connect_watch_fd = pipe_fds[0];
    *watch_fd = pipe_fds[0];
    return ctrl;
}

int libvchan_client_init_async_finish(libvchan_t *ctrl,
                                      __attribute__((unused)) bool blocking) {
    close(ctrl->connect_watch_fd);
    return 0;
}


void libvchan_close(libvchan_t *ctrl) {
    if (ctrl->server_fd >= 0)
        if (close(ctrl->server_fd))
            perror("close server_fd");
    if (ctrl->socket_fd >= 0)
        if (close(ctrl->socket_fd))
            perror("close socket_fd");
    free(ctrl);
}

EVTCHN libvchan_fd_for_select(libvchan_t *ctrl) {
    if (ctrl->socket_fd >= 0)
        return ctrl->socket_fd;
    return ctrl->server_fd;
}
